from flask import Flask, render_template, request, redirect, url_for,flash
from forms import LoginForm
from forms import RegistrationForm, InitialFormSales, ChecklistFormSales, Vendor, Software_Form, Cisco_vendor, Status
# from src.database.schema import Status
from database.db import SessionLocal
import secrets

app = Flask(__name__)

token = secrets.token_hex(16)
app.config["SECRET_KEY"] = token


def db():
    db = SessionLocal()
    try:
        return db
    finally:
        db.close()

@app.route("/", methods=['GET','POST'])
def login():
    
    
    form = LoginForm() 

    if form.validate_on_submit():
        if form.email.data == "samy9211@hotmail.com" and form.password.data == "abc":
            flash('You Have been logged In!', 'primary')
            return redirect(url_for('home'))
        else:
            flash('Invalid Credentials','danger')
        
        
    return render_template('login.html', title ='login', form=form)



@app.route('/home')
def home():
    return render_template('home.html')


@app.route("/register", methods=['GET', 'POST'])
def reg():
    
    form = RegistrationForm()
    if form.validate_on_submit():
        flash(f'Account Created for {form.email.data}!', 'primary')
        return redirect(url_for('home'))
    return render_template('register.html', title ='register', form=form)
    

@app.route('/initial_form',methods=['GET', 'POST'])
def initial():
    form = InitialFormSales()
    if form.validate_on_submit():
        flash(f'initial information, added correctly {form.sales_force_id.data}!','primary')
        return redirect(url_for('home'))
    return render_template("initial_form.html", title= "initial Information", form=form)
    

@app.route('/checklist' , methods=['GET', 'POST'])
def checklist():
    form = ChecklistFormSales()
    formvendor= Vendor()
    form_cisco_vendor= Cisco_vendor()
    formsw= Software_Form()
    
    if form.validate_on_submit():
        flash(f'initial information, added correctly {form.sales_force_id.data}!','primary')
        return redirect(url_for('home'))
    return render_template('checklist.html', form=form, formvendor=formvendor, formsw=formsw, form_cisco_vendor=form_cisco_vendor) 
   
@app.route('/mychecklist',methods=['GET', 'POST'])
def mychecklist():
    form = ChecklistFormSales()
    formvendor= Vendor()
    form_cisco_vendor= Cisco_vendor()
    formsw= Software_Form()
    status = Status()
    
    
    return render_template('mychecklist.html',form=form, formvendor=formvendor, formsw=formsw, form_cisco_vendor=form_cisco_vendor, status=status)


listaPrueba = dict([
      ('SF', '0001'),
      ('QUOTE', 27),
      ('PO', 1003882),
      ('DATE', "01/01/2020"),
      ('STATUS', "APROVED"),

])




@app.route('/history', methods=['GET','POST'])
def history():
    form = ChecklistFormSales()
    return render_template('history_checklist.html',title='Histoy Checklist', form=form)
if __name__ == "__main__":
    app.run(debug=True, port=5000)
